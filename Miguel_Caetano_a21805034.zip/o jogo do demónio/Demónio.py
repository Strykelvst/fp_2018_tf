import pygame
import math
from pygame import mixer

pygame.mixer.pre_init(44100, 16, 2, 4096)
pygame.init()
mixer.init()

#screen

size = (700,857)

#character sprites

walkRight = [pygame.image.load('vegito.png')]
walkLeft = [pygame.image.load('vegito.png')]
walkUp = [pygame.image.load('vegito.png')]
walkDown = [pygame.image.load('vegito.png')]

bg = pygame.image.load('mapa.jpg')
char = pygame.image.load('vegito.png')

screen = pygame.display.set_mode(size)

pygame.display.set_caption ("Save The Future!")

clock = pygame.time.Clock()

score = 0

#music/sound

pygame.mixer.music.load("gb.mp3")
pygame.mixer.music.set_volume(3.0)
pygame.mixer.music.play(-1, 0.0)

arrowSound = pygame.mixer.Sound('bullet.wav')
hitSound = pygame.mixer.Sound('hit.wav')



#character class
class player(object):
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.vel = 40
        self.left = False
        self.right = False
        self.up = False
        self.down = False
        self.walkCount = 0
        self.standing = True
        self.hitbox = (self.x + 20, self.y, 28, 60)
        self.health = 0

    def draw(self,screen):
        if self.walkCount + 1 >=30:
            self.walkCount = 0
        if not(self.standing):
            if self.left:
                screen.blit(walkLeft[self.walkCount//3], (self.x,self.y))
                self.walkCount += 1
            if self.right:
                screen.blit(walkRight[self.walkCount//3], (self.x,self.y))
                self.walkCount += 1
            if self.up:
                screen.blit(walkUp[self.walkCount//3], (self.x,self.y))
                self.walkCount += 1
            if self.down:
                screen.blit(walkDown[self.walkCount//3], (self.x,self.y))
                self.walkCount += 1
        else:
            if self.right:
                screen.blit(walkRight[0], (self.x, self.y))
            else:
                screen.blit(walkLeft[0], (self.x, self.y))
                
        pygame.draw.rect(screen, (255, 0, 0), (self.hitbox[0], self.hitbox[1] - 20, 50, 10))
        pygame.draw.rect(screen, (0, 128, 0), (self.hitbox[0], self.hitbox[1] - 20, 50 - (5 * (10 - self.health)), 10))
        self.hitbox = (self.x, self.y, 50, 87)
        #pygame.draw.rect(screen, (255,0,0), self.hitbox, 2)

    def hit(self):
        self.x = 50
        self.y = 50
        self.walkCount = 0
        font1 = pygame.font.SysFont('arial', 60)
        text = font1.render('Die Mortals!', 1, (255,0,0))
        screen.blit(text, (300 - (text.get_width()/2), 200))
        pygame.display.update()
        i = 0
        while i < 10:
            pygame.time.delay(1)
            i += 1
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    i = 301
                    pygame.quit()

#projectile                
            

class projectile(object):
    def __init__(self, x, y, radius, color, facing):
        self.x = x
        self.y = y
        self.radius = radius
        self.color = color
        self.facing = facing
        self.vel = 10* facing

    def draw(self, screen):
        pygame.draw.circle(screen, self.color, (self.x, self.y), self.radius)

#Monster class
    
class enemy(object):
    walkRight = [pygame.image.load('zamasu.png')]
    walkLeft = [pygame.image.load('zamasu.png')]
    walkUp = [pygame.image.load('zamasu.png')]
    walkDown = [pygame.image.load('zamasu.png')]

    def moveEnemy(self):
        enemy.rect.x = player.rect.x
        enemy.rect.y = player.rect.y
        


    def __init__(self, x, y, width, height, end):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.path = [x, y, end]
        self.walkCount = 0
        self.vel = 30
        self.acc = 20
        self.hitbox = (self.x, self.y, 120, 120)
        self.health = 40
        self.visible  = True
    def move(self, speed=5):

        if self.x > px:
            self.x -= speed
        elif self.x < px:
            self.x += speed
    
        if self.y < py:
            self.y += speed
        elif self.y > py:
            self.y -= speed
        
    def draw(self, screen):
        self.move()
        if self.visible:
            if self.walkCount + 1 <= 33:
                self.walkCount = 0

            if self.vel > 0:
                screen.blit(self.walkRight[self.walkCount//3], (self.x, self.y))
                self.walkCount += 1
            else:
                screen.blit(self.walkLeft[self.walkCount // 3], (self.x, self.y))
                self.walkCount += 1
            pygame.draw.rect(screen, (255,0,0), (self.hitbox[0], self.hitbox[1] - 20, 50, 10))
            pygame.draw.rect(screen, (0, 128, 0), (self.hitbox[0], self.hitbox[1] - 20, 50 - (5 * (10 - self.health)), 10))
            self.hitbox = (self.x, self.y, 70, 120)
            #pygame.draw.rect(screen, (255, 0, 0), self.hitbox, 2)

    def move(self):
        if self.vel > 0:
            if self.x + self.vel < self.path[1]:
                self.x += self.vel
            else:
                self.vel = self.vel * -1
                self.x += self.vel
                self.walkCount = 0
        else:
            if self.x - self.vel > self.path[0]:
                self.x += self.vel
            else:
                self.vel = self.vel * -1
                self.x += self.vel
                self.walkCount = 0
    def hit(self):
        if self.health > 0:
            self.health -= 1
        else:
            self.visible = False
            font1 = pygame.font.SysFont('arial',100)
            text = font1.render('KAMEHAMEAH!', 1, (255, 0, 0))
            screen.blit(text, (300 - (text.get_width()/2), 200))
            pygame.display.update()

#Monster spawn class

class  black(object):
    walkRight = [pygame.image.load('goku black2.png')]
    walkLeft = [pygame.image.load('goku black2.png')]
    walkUp = [pygame.image.load('goku black2.png')]
    walkDown = [pygame.image.load('goku black2.png')]





    def __init__(self, x, y, width, height, end):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.path = [x, y, end]
        self.walkCount = 0
        self.vel = 14
        self.acc = 20
        self.hitbox = (self.x, self.y, 80, 80)
        self.health = 20
        self.visible  = True
    def move(self, speed=5):

        if self.x > px:
            self.x -= speed
        elif self.x < px:
            self.x += speed
    
        if self.y < py:
            self.y += speed
        elif self.y > py:
            self.y -= speed
        
    def draw(self, screen):
        self.move()
        if self.visible:
            if self.walkCount + 1 <= 33:
                self.walkCount = 0

            if self.vel > 0:
                screen.blit(self.walkRight[self.walkCount//3], (self.x, self.y))
                self.walkCount += 1
            else:
                screen.blit(self.walkLeft[self.walkCount // 3], (self.x, self.y))
                self.walkCount += 1
            pygame.draw.rect(screen, (255,0,0), (self.hitbox[0], self.hitbox[1] - 20, 50, 10))
            pygame.draw.rect(screen, (0, 128, 0), (self.hitbox[0], self.hitbox[1] - 20, 50 - (5 * (10 - self.health)), 10))
            self.hitbox = (self.x, self.y, 70, 120)
            #pygame.draw.rect(screen, (255, 0, 0), self.hitbox, 2)

    def move(self):
        if self.vel > 0:
            if self.x + self.vel < self.path[1]:
                self.x += self.vel
            else:
                self.vel = self.vel * -1
                self.x += self.vel
                self.walkCount = 0
        else:
            if self.x - self.vel > self.path[0]:
                self.x += self.vel
            else:
                self.vel = self.vel * -1
                self.x += self.vel
                self.walkCount = 0
    def hit(self):
        if self.health > 0:
            self.health -= 1
        else:
            self.visible = False
            font1 = pygame.font.SysFont('arial',50)
            text = font1.render('KAMEHAMEAH!', 1, (255, 0, 0))
            screen.blit(text, (300 - (text.get_width()/2), 200))
            pygame.display.update()

#poço interdimensional classe

class poço(object):
            
    walkRight = [pygame.image.load('poço.png')]
    walkLeft = [pygame.image.load('poço.png')]
    walkUp = [pygame.image.load('poço.png')]
    walkDown = [pygame.image.load('poço.png')]





    def __init__(self, x, y, width, height, end):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.path = [x, y, end]
        self.walkCount = 0
        self.vel = 1
        self.acc = 20
        self.hitbox = (self.x, self.y, 80, 80)
        self.health = 0
        self.visible  = True
    def move(self, speed=5):

        if self.x > px:
            self.x -= speed
        elif self.x < px:
            self.x += speed
    
        if self.y < py:
            self.y += speed
        elif self.y > py:
            self.y -= speed
        
    def draw(self, screen):
        self.move()
        if self.visible:
            if self.walkCount + 1 <= 33:
                self.walkCount = 0

            if self.vel > 0:
                screen.blit(self.walkRight[self.walkCount//3], (self.x, self.y))
                self.walkCount += 1
            else:
                screen.blit(self.walkLeft[self.walkCount // 3], (self.x, self.y))
                self.walkCount += 1
            pygame.draw.rect(screen, (255,0,0), (self.hitbox[0], self.hitbox[1] - 0, 0, 0))
            pygame.draw.rect(screen, (0, 128, 0), (self.hitbox[0], self.hitbox[1] - 0, 0 - (5 * (0 - self.health)), 0))
            self.hitbox = (self.x, self.y, 70, 120)
            #pygame.draw.rect(screen, (255, 0, 0), self.hitbox, 2)

    def move(self):
        if self.vel > 0:
            if self.x + self.vel < self.path[1]:
                self.x += self.vel
            else:
                self.vel = self.vel * -1
                self.x += self.vel
                self.walkCount = 0
        else:
            if self.x - self.vel > self.path[0]:
                self.x += self.vel
            else:
                self.vel = self.vel * -1
                self.x += self.vel
                self.walkCount = 0
    def hit(self):
        if self.health > 0:
            self.health -= 0
        else:
            self.visible = False
            font1 = pygame.font.SysFont('arial',50)
            text = font1.render('KAMEHAMEAH!', 1, (255, 0, 0))
            screen.blit(text, (300 - (text.get_width()/2), 200))
            pygame.display.update()




#draw stuff

def redrawGameWindow():
    screen.blit(bg, (0,0))
    text = font.render ('Score: ' + str(score), 1, (0,0,0))
    screen.blit(text, (390, 10))
    man.draw(screen)
    monster.draw(screen)
    spawn.draw(screen)
    bicho.draw(screen)
    harambe.draw(screen)
    karatekid.draw(screen)
    atuaprimamercias.draw(screen)
    pussidonio.draw(screen)
    poço1.draw(screen)
    
    
    for arrow in arrows:
        arrow.draw(screen)

    pygame.display.update()

#Object Coordinates
         
font = pygame.font.SysFont('arial', 30, True)
man = player(100, 100, 64, 64)
monster = enemy(100, 500, 499, 700, 500)
spawn = black(110, 600, 350, 200, 350)
bicho = black(150, 400, 100, 40, 450)
harambe = black(20,300, 630, 440, 300)
karatekid= black(104, 700, 300, 200, 450)
atuaprimamercias = black(190, 620, 400, 100, 250)
pussidonio = black(50, 450, 150, 550, 210)
poço1 = poço(500,300, 300, 300, 100)



arrows = []
run = True
while run:
    clock.tick(30)

#Monster collision

    if monster.visible == True:
        if man.hitbox[1] < monster.hitbox[1] + monster.hitbox[3] and man.hitbox[1] + man.hitbox[3] > monster.hitbox[1]:
            if man.hitbox[0] + man.hitbox[2] > monster.hitbox[0] and man.hitbox[0] < monster.hitbox[0] + monster.hitbox[2]:
                man.hit()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    for arrow in arrows:
        if arrow.y - arrow.radius < monster.hitbox[1] + monster.hitbox[3] and arrow.y + arrow.radius > monster.hitbox[1]:
            if arrow.x + arrow.radius > monster.hitbox[0] and arrow.x - arrow.radius < monster.hitbox[0] + monster.hitbox[2]:
                hitSound.play()
                monster.hit()
                score += 10
                arrows.pop(arrows.index(arrow))

        if arrow.x < 800 and arrow.x > 0:
            arrow.x += arrow.vel
        else:
            arrows.pop(arrows.index(arrow))

#Spawn collisiom

    if spawn.visible == True:
        if man.hitbox[1] < spawn.hitbox[1] + spawn.hitbox[3] and man.hitbox[1] + man.hitbox[3] > spawn.hitbox[1]:
            if man.hitbox[0] + man.hitbox[2] > spawn.hitbox[0] and man.hitbox[0] < spawn.hitbox[0] + spawn.hitbox[2]:
                man.hit()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    for arrow in arrows:
        if arrow.y - arrow.radius < spawn.hitbox[1] + spawn.hitbox[3] and arrow.y + arrow.radius > spawn.hitbox[1]:
            if arrow.x + arrow.radius > spawn.hitbox[0] and arrow.x - arrow.radius < spawn.hitbox[0] + spawn.hitbox[2]:
                hitSound.play()
                spawn.hit()
                score += 1
                arrows.pop(arrows.index(arrow))

        if arrow.x < 800 and arrow.x > 0:
            arrow.x += arrow.vel
        else:
            arrows.pop(arrows.index(arrow))

#bicho colisiom

            
    if bicho.visible == True:
        if man.hitbox[1] < bicho.hitbox[1] + bicho.hitbox[3] and man.hitbox[1] + man.hitbox[3] > bicho.hitbox[1]:
            if man.hitbox[0] + man.hitbox[2] > bicho.hitbox[0] and man.hitbox[0] < bicho.hitbox[0] + bicho.hitbox[2]:
                man.hit()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    for arrow in arrows:
        if arrow.y - arrow.radius < bicho.hitbox[1] + bicho.hitbox[3] and arrow.y + arrow.radius > bicho.hitbox[1]:
            if arrow.x + arrow.radius > bicho.hitbox[0] and arrow.x - arrow.radius < bicho.hitbox[0] + bicho.hitbox[2]:
                hitSound.play()
                bicho.hit()
                score += 1
                arrows.pop(arrows.index(arrow))

        if arrow.x < 800 and arrow.x > 0:
            arrow.x += arrow.vel
        else:
            arrows.pop(arrows.index(arrow))

#harambe collison:

    if harambe.visible == True:
        if man.hitbox[1] < harambe.hitbox[1] + harambe.hitbox[3] and man.hitbox[1] + man.hitbox[3] > harambe.hitbox[1]:
            if man.hitbox[0] + man.hitbox[2] > harambe.hitbox[0] and man.hitbox[0] < harambe.hitbox[0] + harambe.hitbox[2]:
                man.hit()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    for arrow in arrows:
        if arrow.y - arrow.radius < harambe.hitbox[1] + harambe.hitbox[3] and arrow.y + arrow.radius > harambe.hitbox[1]:
            if arrow.x + arrow.radius > harambe.hitbox[0] and arrow.x - arrow.radius < harambe.hitbox[0] + harambe.hitbox[2]:
                hitSound.play()
                harambe.hit()
                score += 1
                arrows.pop(arrows.index(arrow))

        if arrow.x < 800 and arrow.x > 0:
            arrow.x += arrow.vel
        else:
            arrows.pop(arrows.index(arrow))

#karatekid collision

    if bicho.visible == True:
        if man.hitbox[1] < karatekid.hitbox[1] + karatekid.hitbox[3] and man.hitbox[1] + man.hitbox[3] > karatekid.hitbox[1]:
            if man.hitbox[0] + man.hitbox[2] > karatekid.hitbox[0] and man.hitbox[0] < karatekid.hitbox[0] + karatekid.hitbox[2]:
                man.hit()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    for arrow in arrows:
        if arrow.y - arrow.radius < karatekid.hitbox[1] + karatekid.hitbox[3] and arrow.y + arrow.radius > karatekid.hitbox[1]:
            if arrow.x + arrow.radius > karatekid.hitbox[0] and arrow.x - arrow.radius < karatekid.hitbox[0] + karatekid.hitbox[2]:
                hitSound.play()
                karatekid.hit()
                score += 1
                arrows.pop(arrows.index(arrow))

        if arrow.x < 800 and arrow.x > 0:
            arrow.x += arrow.vel
        else:
            arrows.pop(arrows.index(arrow))

#a tua prima mercias
    if atuaprimamercias.visible == True:
        if man.hitbox[1] < atuaprimamercias.hitbox[1] + atuaprimamercias.hitbox[3] and man.hitbox[1] + man.hitbox[3] > atuaprimamercias.hitbox[1]:
            if man.hitbox[0] + man.hitbox[2] > atuaprimamercias.hitbox[0] and man.hitbox[0] < atuaprimamercias.hitbox[0] + atuaprimamercias.hitbox[2]:
                man.hit()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    for arrow in arrows:
        if arrow.y - arrow.radius < atuaprimamercias.hitbox[1] + atuaprimamercias.hitbox[3] and arrow.y + arrow.radius > atuaprimamercias.hitbox[1]:
            if arrow.x + arrow.radius > atuaprimamercias.hitbox[0] and arrow.x - arrow.radius < atuaprimamercias.hitbox[0] + atuaprimamercias.hitbox[2]:
                hitSound.play()
                atuaprimamercias.hit()
                score += 1
                arrows.pop(arrows.index(arrow))

        if arrow.x < 800 and arrow.x > 0:
            arrow.x += arrow.vel
        else:
            arrows.pop(arrows.index(arrow))

#pussidonio
    if pussidonio.visible == True:
       if man.hitbox[1] < pussidonio.hitbox[1] + pussidonio.hitbox[3] and man.hitbox[1] + man.hitbox[3] > pussidonio.hitbox[1]:
            if man.hitbox[0] + man.hitbox[2] > pussidonio.hitbox[0] and man.hitbox[0] < pussidonio.hitbox[0] + pussidonio.hitbox[2]:
                man.hit()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    for arrow in arrows:
        if arrow.y - arrow.radius < pussidonio.hitbox[1] + pussidonio.hitbox[3] and arrow.y + arrow.radius > pussidonio.hitbox[1]:
            if arrow.x + arrow.radius > pussidonio.hitbox[0] and arrow.x - arrow.radius < pussidonio.hitbox[0] + pussidonio.hitbox[2]:
                hitSound.play()
                pussidonio.hit()
                score += 1
                arrows.pop(arrows.index(arrow))

        if arrow.x < 800 and arrow.x > 0:
            arrow.x += arrow.vel
        else:
            arrows.pop(arrows.index(arrow))

#poço 1 coliosione
            
    if poço1.visible == True:
       if man.hitbox[1] < poço1.hitbox[1] + poço1.hitbox[3] and man.hitbox[1] + man.hitbox[3] > poço1.hitbox[1]:
            if man.hitbox[0] + man.hitbox[2] > poço1.hitbox[0] and man.hitbox[0] < poço1.hitbox[0] + poço1.hitbox[2]:
                man.hit()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    for arrow in arrows:
        if arrow.y - arrow.radius < poço1.hitbox[1] + poço1.hitbox[3] and arrow.y + arrow.radius > poço1.hitbox[1]:
            if arrow.x + arrow.radius > poço1.hitbox[0] and arrow.x - arrow.radius < poço1.hitbox[0] + poço1.hitbox[2]:
                hitSound.play()
                poço1.hit()
                score += 1
                arrows.pop(arrows.index(arrow))

        if arrow.x < 800 and arrow.x > 0:
            arrow.x += arrow.vel
        else:
            arrows.pop(arrows.index(arrow))






    keys = pygame.key.get_pressed()

    if keys[pygame.K_SPACE]:
        arrowSound.play()
        if man.left:
            facing = -1
        else:
            facing = 1

        if len(arrows) < 1:
            arrows.append(projectile(round(man.x + man.width//2), round(man.y + man.height//2), 6, (0, 0, 0), facing))

    if keys[pygame.K_LEFT] and man.x > man.vel:
        man.x -= man.vel
        man.standing = False
    if keys[pygame.K_RIGHT] and man.x < 700 - man.width - man.vel:
        man.x += man.vel
        man.standing = False
    if keys[pygame.K_UP] and man.y > man.vel:
        man.y -= man.vel
        man.standing = False
    if keys[pygame.K_DOWN] and man.y < 857 - man.height - man.vel:
        man.y += man.vel
        man.standing = False
    else:
        man.standing = True
        man.walkCount = 0

    redrawGameWindow()

pygame.quit()
